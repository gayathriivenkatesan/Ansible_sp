##############################################################################################
#                        SSH Connection to remote servers                                    #        
##############################################################################################

import paramiko


def connect(hostname,user,pwd,pt):
    try:
        ssh = paramiko.SSHClient()
        ssh.load_system_host_keys()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        ssh.connect(hostname =hostname, username =user, password =pwd, port = pt, banner_timeout= 1000)
        status="Connection Established"
    except paramiko.AuthenticationException:
            print("Authentication Failed")
            exit()
            
            
    except paramiko.SSHException:
            print("Issues with SSH service")
            exit()
            

    except  Exception as e:
        if (type(e).__name__=="TimeoutError"):
            print("Unable to connect to {}".format(hostname))
            return "Unable to connect"
        print(e)
        return "Something went wrong..."
        
    if status=="Connection Established":
        return ssh
