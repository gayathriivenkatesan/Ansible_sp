#########################################################
#
#       Printer Queue Configuration
#
#########################################################


import time
import connection1
import getpass
import os
import re
import warnings
import socket
import pandas as pd
from openpyxl import Workbook
warnings.filterwarnings('ignore')
from openpyxl.styles import Color, PatternFill, Font, Border
from openpyxl.styles import colors
from openpyxl.cell import Cell


#Get the username and password
user=input("Enter the Username:")
pwd=getpass.getpass("Enter the Password:")
pt='2022'


def fun1(server,printer_type,serverIP,queue_name):
    try:
        x=""
        x1=""
        x2=""
        e=""

        #connect to server 
        op_ssh=connection1.connect(server,user,pwd,pt)
        if op_ssh!="Unable to connect" and op_ssh!="Something went wrong...":
            chan=op_ssh.invoke_shell()
            chan.send("sudo su -"+"\n")
            time.sleep(3)
            out0=chan.recv(10000000000000)
            s=str(out0).split("\\n")[-1].replace("'","")
            print(s)

            #Checking for CUPS Package
            chan.send("rpm -qa |grep cups"+"\n")
            time.sleep(5)
            out1=chan.recv(10000000000000)
            print(out1)


			
            #Installing package if already not present 
            if(str(out1).split("\\n")[1]).__contains__(s):
                print("Package already not Found")
                print("Installing the package ....")
                chan.send("yum install cups"+"\n")
                time.sleep(10)
                chan.send("rpm -qa |grep cups"+"\n")
                time.sleep(5)
                out1d=chan.recv(10000000000000)
                print(out1d)
                if(str(out1d).split("\\n")[1]).__contains__(s):
                    print("Unable to install Cups")
                    e="Unable to install Cups "
                    print("Exit from Linux server")
                    chan.send("exit"+"\n")
                    chan.close()
                    time.sleep(3)
                else:
                    chan.send("if [ -f /usr/bin/systemctl ]; then systemctl start cups; else service cups start; fi" + "\n")
                    time.sleep(2)
                    chan.send("if [ -f /usr/bin/systemctl ]; then systemctl enable cups; else chkconfig cups on; fi" + "\n")
                    time.sleep(2)
                    out32=chan.recv(10000000000000)
                    chan.send("if [ -f /usr/bin/systemctl ]; then systemctl status cups; else service cups status; fi >> /dev/null; echo $?" + "\n")
                    time.sleep(2)
                    out31=chan.recv(10000000000000)
                    s21=str(out31).split("\\n")[-2].replace("\\r","")
                    if str(s21) != "0":
                        x="Failed"
                        print("Failed - Unable to activate the CUPS service : Error code {}".format(s2))
                    else:
                        x="Success"
                        print("Success - CUPS status is activated")

            else:
                print("Package already present")
                chan.send("if [ -f /usr/bin/systemctl ]; then systemctl status cups; else service cups status; fi >> /dev/null; echo $?" + "\n")
                time.sleep(2)
                out2=chan.recv(10000000000000)
                print(out2)
                s1=str(out2).split("\\n")[-2].replace("\\r","")
                if str(s1) != "0":
                     chan.send("if [ -f /usr/bin/systemctl ]; then systemctl start cups; else service cups start; fi" + "\n")
                     time.sleep(2)
                     chan.send("if [ -f /usr/bin/systemctl ]; then systemctl enable cups; else chkconfig cups on; fi" + "\n")
                     time.sleep(2)
                     chan.send("if [ -f /usr/bin/systemctl ]; then systemctl status cups; else service cups status; fi >> /dev/null; echo $?" + "\n")      
                     time.sleep(2)
                     out3=chan.recv(10000000000000)
                     s2=str(out3).split("\\n")[-2].replace("\\r","")
                     if str(s2) != "0":
                         x="Failed"
                         print("Failed - Unable to activate the CUPS service : Error code {}".format(s2))
                     else:
                         x="Success"
                         print("Success - CUPS status is activated")
                else:
                    x="Success"
                    print("Success - Already CUPS is active")


            print(x)
            if x == "Failed":
                print("Exit from Linux server")
                chan.send("exit"+"\n")
                chan.close()
                time.sleep(3)     
            else:
                if printer_type == 'LPD BASED':
                             
                    #lpadmin -t <print queue name> -E -v lpd://<print server IP>/<print queue name>
                    #lpadmin -p automationtest -E -v lpd://10.27.102.82/automationtest
                    #lpstat -t | grep automationtest

                    s3=("lpadmin -p {} -E -v lpd://{}/{}".format(queue_name,serverIP,queue_name))
                    print(s3)
                    chan.send(s3+"\n")
                    time.sleep(2)

                             
                    #lpstat -t |grep <print queue name>
                    
                    s4=("lpstat -t |grep {}".format(queue_name))
                    print(s4)
                    chan.send(s4+"\n")
                    time.sleep(2)
                    out4=chan.recv(10000000000000)
                             
                    #cupsaccept <print queue name>
                    #cupsenable <print queue name>
                             
                    s6=("cupsaccept {}".format(queue_name))
                    s7=("cupsenable {}".format(queue_name))
                             
                    print(s6)
                    print(s7)
                           
                    if str(out4).__contains__("enabled"):        
                        if str(out4).__contains__("accepting"):
                            x1="Success"
                            print("Success - Already Enabled and Accepting")

                        else:
                            chan.send(s6+"\n")
                            time.sleep(3)
                            out6=chan.recv(10000000000000)
                            chan.send(s4)
                            time.sleep(3)
                            out7=chan.recv(10000000000000)
                            if str(out7).__contains__("enabled") and str(out7).__contains__("accepting"):
                                x1="Success"
                                print("Success -Enabled and Accepting")
                            else:
                                x1="Failed"
                                print("Failed -Enabled and Accepting")
                                print("Exit from Linux server")
                                chan.send("exit"+"\n")
                                time.sleep(3)
                                chan.close()

                    else:
                        chan.send(s7+"\n")
                        time.sleep(2)
                        chan.send(s6+"\n")
                        time.sleep(2)
                        out42=chan.recv(100000000000000)
                        chan.send(s4+"\n")
                        time.sleep(2)
                        out41=chan.recv(100000000000000)
                        if str(out41).__contains__("enabled") and str(out41).__contains__("accepting"):
                            x1="Success"
                            print("Success -Enabled and Accepting")
                        else:
                            x1="Failed"
                            print("Failed -Enabled and Accepting") 
                            print("Exit from Linux server")
                            chan.send("exit"+"\n")
                            time.sleep(3)
                            chan.close()

                 
                    if x1.__contains__("Success"):
                        s5=("telnet {} 515".format(serverIP))
                        print(s5)
                        chan.send(s5+"\n")
                        time.sleep(3)
                        out5=chan.recv(10000000000000)
                        if str(out5).__contains__("Connected"):
                            print("Printer is able to communicate to server")
                            x2="Success"
                        else:
                            print("Failed to communicate to server port")
                            x2="Failed"


                    else:
                        print("Unable to enable the printer queue")
                        x1="Failed"
                        chan.send("exit"+"\n")
                        time.sleep(3)
                        chan.close()
    
                elif  printer_type == 'APPSOCKET':
				
                    #lpadmin -p MPL8-VP -E -v socket://10.121.244.43:9100
                    # lpadmin -p <print queue name> -E -v socket://<print server IP>:<port>

                    s31=("lpadmin -p {} -E -v socket://{}:9100".format(queue_name,serverIP))
                    print(s31)
                    chan.send(s31+"\n")
                    time.sleep(2)
             
                    #lpstat -t |grep <print queue name>
                    
                    s41=("lpstat -t |grep {}".format(queue_name))
                    print(s41) 
                    chan.send(s41+"\n")
                    time.sleep(2)
                    out40=chan.recv(10000000000000)
                             
                    #cupsaccept <print queue name>
                    #cupsenable <print queue name>
                             
                    s61=("cupsaccept {}".format(queue_name))
                    s71=("cupsenable {}".format(queue_name))
                             
                    print(s61)
                    print(s71)
					
					
                    if str(out40).__contains__("enabled"):        
                        if str(out40).__contains__("accepting"):
                            x1="Success"
                            print("Success - Already Enabled and Accepting")

                        else:
                            chan.send(s61+"\n")
                            time.sleep(3)
                            out61=chan.recv(10000000000000)
                            chan.send(s40)
                            time.sleep(3)
                            out71=chan.recv(10000000000000)
                            if str(out71).__contains__("enabled") and str(out71).__contains__("accepting"):
                                x1="Success"
                                print("Success -Enabled and Accepting")
                            else:
                                x1="Failed"
                                print("Failed -Enabled and Accepting")
                                print("Exit from Linux server")
                                chan.send("exit"+"\n")
                                time.sleep(3)
                                chan.close()

                    else:
                        chan.send(s71+"\n")
                        time.sleep(2)
                        chan.send(s61+"\n")
                        time.sleep(2)
                        out421=chan.recv(100000000000000)
                        chan.send(s41+"\n")
                        time.sleep(2)
                        out411=chan.recv(100000000000000)
                        if str(out411).__contains__("enabled") and str(out411).__contains__("accepting"):
                            x1="Success"
                            print("Success -Enabled and Accepting")
                        else:
                            x1="Failed"
                            print("Failed -Enabled and Accepting")
                            print("Exit from Linux server")
                            chan.send("exit"+"\n")
                            time.sleep(3)
                            chan.close()
    
                    if x1.__contains__("Success"):
                        s51=("telnet {} 9100".format(serverIP))
                        print(s51)
                        chan.send(s51+"\n")
                        time.sleep(3)
                        out51=chan.recv(10000000000000)
                        if str(out51).__contains__("Connected"):
                            print("Printer is able to communicate to server")
                            x2="Success"
                        else:
                            print("Failed to communicate to server port")
                            x2="Failed"
                            print("Exit from Linux server")
                            chan.send("exit"+"\n")
                            time.sleep(3)
                            chan.close()
                            

                    else:
                        print("Unable to enable the printer queue")
                        print("Exit from Linux server")
                        chan.send("exit"+"\n")
                        time.sleep(3)
                        chan.close()
                        
                        
                else:
                    print("Please reach out to Unix L2 team to configure")
                    e="Please reach out to Unix L2 team to configure"
		    
                        
                """elif printer_type == 'CUPS Class based printer configuration (HA)':
                    print("Please reach out to Unix L2 team to configure")

		elif printer_type == 'LPD based printing using a ppd file':
		    print("Please reach out to Unix L2 team to configure")

		elif printer_type == 'HTTPS based printer configuration':
		    print("Please reach out to Unix L2 team to configure")"""
                
        else:
            print("Unable to Connect to server")
            e="Unable to Connect to server"
            
    except Exception as e:
        print(e)
	
    return x,x1,x2,e


#Server Name,Printer Type,Server IP,Queue Name
inputfile= os.path.join(os.getcwd(),"input.xlsx")
outputfile= os.path.join(os.getcwd(),"printer_queue_output"+time.strftime('%Y-%m-%d=%H-%M')+".xlsx")

#For output file
headers=['Server Name','Printer Type','Server IP','Queue Name','CUP Status','Queue Status','Telnet Status','Error Message']
book = Workbook()
sheet = book.active
sheet.append(headers)


s=pd.read_excel(inputfile)
for i in range (len(s)):
    server=s['Server Name'][i]
    print(server)
    printer_type=(s['Printer Type(LPD based/AppSocket)'][i]).upper()
    print(printer_type)
    serverIP=s['Server IP'][i]
    print(serverIP)
    queue_name=s['Queue Name'][i]
    print(queue_name)
    a=fun1(server,printer_type,serverIP,queue_name)
    y=[]
    #Writing to output file 
    redFill = PatternFill(start_color='FFFF0000',end_color='FFFF0000',fill_type='solid') 	
    greenFill= PatternFill(start_color='00FF00',end_color='00FF00',fill_type='solid') 
    y=[server,printer_type,serverIP,queue_name,a[0],a[1],a[2],a[3]]
    sheet.append(y)
    book.save(outputfile)
    
df=pd.read_excel(outputfile)
styled = df.style.applymap(lambda val: 'background-color: %s' % 'green' if val == "Success" else 'background-color: %s' % 'Red' if val == "Failed" else  'color: %s' % 'black' )
Styled=df.style.apply(df['Server Name'], axis = None)
#Styled=(df[['Server Name', 'Printer Type', 'Server IP','Queue Name']] = 'background-color: grey')
styled.to_excel(outputfile, engine='openpyxl',index=False)

    
    



